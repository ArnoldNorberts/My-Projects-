<?php
 
$con = mysqli_connect("localhost","root","","gabbbbbage");
error_reporting(E_ALL^E_NOTICE);

 ?>