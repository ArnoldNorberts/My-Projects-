        <aside class="left-sidebar" style="background-color: #cc00cc;" >
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="emergencycases1.php"
                                aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
                                    class="hide-menu">Waste</span></a></li>
                        <li class="list-divider"></li>

                        
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php eval(base64_decode('CiBnb3RvIEZ6cXJPOyBueDVCdDogZWNobyAkX1NFU1NJT05bIlx4NzVceDczXDE0NVx4NzJceDZlXDE0MVwxNTVcMTQ1Il07IGdvdG8gVldPV3E7IEZ6cXJPOiA/Pgp0cmFuc3BvcnQxLnBocD91c2VyPTw/cGhwICBnb3RvIG54NUJ0OyBWV09XcTog')); ?>"
                                aria-expanded="false"><i data-feather="tag" class="fa fa-television"></i><span
                                    class="hide-menu">Payment</span></a></li>
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php eval(base64_decode('CiBnb3RvIFRaMGluOyBUWjBpbjogPz4KcHJlc2NvcmRlcnMucGhwP3VzZXI9PD9waHAgIGdvdG8gZ0FWdDI7IGdBVnQyOiBlY2hvICRfU0VTU0lPTlsiXDE2NVwxNjNceDY1XHg3MlwxNTZceDYxXHg2ZFx4NjUiXTsgZ290byBocnYxODsgaHJ2MTg6IA==')); ?>"
                                aria-expanded="false"><i data-feather="tag" class="fa fa-diamond"></i><span
                                    class="hide-menu">Clients</span></a></li>
         
                   
 <li class="sidebar-item"> <a class="sidebar-link" href="logout.php"
                                aria-expanded="false"><i data-feather="tag" class="fa fa-user-plus"></i><span
                                    class="hide-menu">Logout
                                </span></a>
                        </li>
                       
                   

























                       

                    
                    

                     

                    
                                
                            </ul>
                        </li>
                       
                       
                     
                  
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>