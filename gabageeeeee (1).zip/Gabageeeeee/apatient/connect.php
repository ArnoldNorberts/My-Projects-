<?php
 
$con = mysqli_connect("localhost","root","","gabbage");
error_reporting(E_ALL^E_NOTICE);

 ?>